<?php

return [
    '%d second%s ago' => '%d秒前',
    '%d minute%s ago' => '%d分钟前',
    '%d hour%s ago'   => '%d小时前',
    '%d day%s ago'    => '%d天前',
    '%d week%s ago'   => '%d周前',
    '%d month%s ago'  => '%d月前',
    '%d year%s ago'   => '%d年前'
];
