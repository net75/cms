<?php

return [
    'Id'          => 'ID',
    'Category'    => '分类',
    'Flag'        => '标志',
    'Title'       => '标题',
    'Summary'     => '摘要',
    'Content'     => '内容',
    'Thumb'       => '缩略图',
    'Image'       => '大图',
    'Keywords'    => '关键字',
    'Description' => '描述',
    'Views'       => '点击',
    'Comments'    => '评论数',
    'Createtime'  => '创建时间',
    'Updatetime'  => '更新时间',
    'Weigh'       => '权重',
    'Status'      => '状态'
];
