<?php

return [
    'Id'         => 'ID',
    'Post'       => '日志',
    'Pid'        => '父评论ID',
    'Username'   => '用户名',
    'Email'      => '邮箱',
    'Website'    => '网址',
    'Content'    => '内容',
    'Comments'   => '评论数',
    'Ip'         => 'IP',
    'Useragent'  => '浏览器',
    'Subscribe'  => '订阅',
    'Createtime' => '创建时间',
    'Updatetime' => '更新时间',
    'Status'     => '状态'
];
