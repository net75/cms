<?php

return [
    'Id'          => 'ID',
    'Category_id' => '分类ID',
    'Type'        => '类型',
    'Title'       => '标题',
    'Keywords'    => '关键字',
    'Description' => '描述',
    'Flag'        => '标志',
    'Image'       => '图片',
    'Content'     => '内容',
    'Icon'        => '图标',
    'Views'       => '点击',
    'Comments'    => '评论',
    'Diyname'     => '自定义',
    'Showtpl'     => '视图模板',
    'Createtime'  => '创建时间',
    'Updatetime'  => '更新时间',
    'Weigh'       => '权重',
    'Status'      => '状态'
];
